import mongoose  from 'mongoose'
import { Schema } from "mongoose"

const EstadoDao = new Schema({
    nome: {
        type: String
    },
    sigla: {
        type: String
    },
    criadoEm: {
        type: String
    },
    atualizadoEm:{
        type: String
    }
   
});

export default  mongoose.model("Estado", EstadoDao);